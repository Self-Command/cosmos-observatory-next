export default {
  // commands (utils.ts)
  'any-block-rebuild-view': '刷新/重建当前视图',
  'any-block-rebuild-view-btn': '刷新视图',

  'any-block-to-codeblock': '将 anyblock 区块转换为代码块格式',
  'any-block-to-codeblock-success': '转换成功! 已生成到 ',
  'any-block-to-codeblock-fail': '转换失败，请检查控制台以获取详细信息',

  'any-block-delete-ab-header': '删除 AnyBlock 方括号头部',
  'any-block-switch-disable': '切换 AnyBlock 启用/禁用',

  // setting.ts
  'Mini docs': `mini文档`,
  'see website for detail': `查看 
    <a href="https://lincdocs.github.io/AnyBlock/README.show.html">website</a>
    /
    <a href="https://github.com/LincZero/obsidian-any-block">github</a>
    文档以获取更多细节 | 作者: <a href="https://github.com/LincZero">LincZero</a>`,
  'Mini docs menu': `如何可视化创建AnyBlock?`,
  'Mini docs menu2': `推荐使用
    <a href="https://github.com/any-menu/any-menu">AnyMenu</a>
    插件 (同作者开发)，以使用菜单面板或搜索框快速输入 AnyBlock 模板`,

  'Selector manager': '选择器',
  'Selector manager2': '这一部分仅供查询不可编辑',

  'AliasSystem manager': '别名系统',
  'AliasSystem manager2': '这部分内容可以使用 `[info_alias]` 处理器在主页面中查看',
  'AliasSystem manager3': '这部分也可以打开插件文件夹中的 `data.json` 文件修改',
  'AliasSystem manager4': '添加新的注册指令',
  'AliasSystem manager5': '添加新的注册指令 - 旧版，将弃用',

  'Convertor manager': '转换器/处理器',
  'Convertor manager2': '这部分内容可以使用 `[info_converter]` 处理器在主页面中查看',
  'Convertor manager3': '这一部分仅供查询不可编辑',

  'Custom alias': '自定义别名',
  'Custom alias2': '别名匹配规则',
  'Custom alias3': '若用`/`包括起来则表示正则',
  'Custom alias4': '别名替换为',
  'Custom alias5': '暂不开放带参数的替换功能，如多人需要才开放',

  'Custom processor': '自定义处理器 - 将废弃',
  'Custom processor2': '处理器唯一id',
  'Custom processor3': '不与其他处理器冲突即可',
  'Custom processor4': '注册器名',
  'Custom processor5': '可以随便填，给自己看的',
  'Custom processor6': '注册器匹配名',
  'Custom processor7': '用 `/` 包括起来则表示正则',
  'Custom processor8': '注册器替换为',
  'Custom processor9': '用 `/` 包括起来则表示正则',

  'Pro': 'Pro',
  'Pro2': 'Pro 版增强选项',
  'Pro disable': '禁用 Pro 版功能',
  'Pro disable2': '(修改后需要重启插件) \
禁用 Pro 版功能，开启后等同于非 Pro 版功能，便于调试 bug 或功能是否该模块产生的',
  'Pro editableblock render': '可编辑块的默认渲染',
  'Pro editableblock render2': '可编辑块的默认渲染模式',
  'Pro editableblock render21': '- 阅读模式: 需要使用中键进入编辑，中键/Esc/光标外部聚焦完成编辑',
  'Pro editableblock render22': '- 实时模式: 可直接编辑但会更吃性能',
  'Pro editableblock render23': '- 简易文本框: 显示为纯文本，适合子块不包含复杂md的情况',
  'Pro editableblock render24': '- 仅编辑时接管 (开发中): 不修改默认渲染逻辑，仅中键将其修改为可编辑状态',
  'Pro editableblock render3': '阅读模式',
  'Pro editableblock render4': '实时模式',
  'Pro editableblock render5': '简易文本框',
  'Pro alias override': 'Pro 别名覆盖',
  'Pro alias override2': '(重启插件生效) \
将原处理器行为替换为 pro 对应处理器的行为。若关闭则可编辑版本与原版本分别使用不同的处理器名',
  'Pro callout': 'Callout 选择器',
  'Pro callout2': '使用 Callout 选择器，并启用可编辑 Callout',

  'License': '许可证',
  'License2': '这是Pro版的许可证，到期时间的显示需要重新打开设置面板来更新\n\
采用双许可证机制，每次更新都会给一定时长的默认免费许可证 (与用户许可证并存)',
  'License key': '许可证密钥',
  'License Expiry': '许可证到期时间，到期时间的显示需要重新打开设置面板来更新',

  // General
  'Submit': '提交',
  'Edit': '编辑',
  'Refresh': '刷新',
  'Delete': '删除',
  'Save': '保存',
  'Cancel': '取消',
  'Close': '关闭',
}
