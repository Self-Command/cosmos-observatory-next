import { InternalModule } from "../InternalModule";
import { PromptModal } from "./PromptModal";
import { SuggesterModal } from "./SuggesterModal";
import { TemplaterError } from "utils/Error";
import { ModuleName } from "editor/TpDocumentation";
import { MultiSuggesterModal } from "./MultiSuggesterModal";

export class InternalModuleSystem extends InternalModule {
    public name: ModuleName = "system";

    async create_static_templates(): Promise<void> {
        this.static_functions.set("clipboard", this.generate_clipboard());
        this.static_functions.set("prompt", this.generate_prompt());
        this.static_functions.set("suggester", this.generate_suggester());
        this.static_functions.set(
            "multi_suggester",
            this.generate_multi_suggester()
        );
    }

    async create_dynamic_templates(): Promise<void> {}

    async teardown(): Promise<void> {}

    generate_clipboard(): () => Promise<string | null> {
        return async () => {
            return await navigator.clipboard.readText();
        };
    }

    generate_prompt(): (
        prompt_text: string,
        default_value: string,
        throw_on_cancel: boolean,
        multi_line: boolean,
        select_default_value: boolean
    ) => Promise<string | null> {
        return async (
            prompt_text: string,
            default_value: string,
            throw_on_cancel = false,
            multi_line = false,
            select_default_value = false
        ): Promise<string | null> => {
            const prompt = new PromptModal(
                this.plugin.app,
                prompt_text,
                default_value,
                multi_line,
                select_default_value
            );
            const promise = new Promise(
                (
                    resolve: (value: string) => void,
                    reject: (reason?: TemplaterError) => void
                ) => { void prompt.openAndGetValue(resolve, reject); }
            );
            try {
                return await promise;
            } catch (error) {
                if (throw_on_cancel) {
                    throw error;
                }
                return null;
            }
        };
    }

    generate_suggester(): <T>(
        text_items: string[] | ((item: T) => string),
        items: T[],
        throw_on_cancel: boolean,
        placeholder: string,
        limit?: number,
        default_value?: T
    ) => Promise<T> {
        return async <T>(
            text_items: string[] | ((item: T) => string),
            items: T[],
            throw_on_cancel = false,
            placeholder = "",
            limit?: number,
            default_value?: T
        ): Promise<T> => {
            const suggester = new SuggesterModal(
                this.plugin.app,
                text_items,
                items,
                placeholder,
                limit,
                default_value
            );
            const promise = new Promise(
                (
                    resolve: (value: T) => void,
                    reject: (reason?: TemplaterError) => void
                ) => { void suggester.openAndGetValue(resolve, reject); }
            );
            try {
                return await promise;
            } catch (error) {
                if (throw_on_cancel) {
                    throw error;
                }
                return null as T;
            }
        };
    }

    generate_multi_suggester(): <T>(
        text_items: string[] | ((item: T) => string),
        items: T[],
        throw_on_cancel: boolean,
        title: string,
        limit?: number,
        default_values?: T[]
    ) => Promise<T[]> {
        return async <T>(
            text_items: string[] | ((item: T) => string),
            items: T[],
            throw_on_cancel = false,
            title = "",
            limit?: number,
            default_values?: T[]
        ): Promise<T[]> => {
            const suggester = new MultiSuggesterModal(
                this.plugin.app,
                text_items,
                items,
                title,
                limit,
                default_values
            );
            const promise = new Promise(
                (
                    resolve: (values: T[]) => void,
                    reject: (reason?: TemplaterError) => void
                ) => { void suggester.openAndGetValue(resolve, reject); }
            );
            try {
                return await promise;
            } catch (error) {
                if (throw_on_cancel) {
                    throw error;
                }
                return [];
            }
        };
    }
}
